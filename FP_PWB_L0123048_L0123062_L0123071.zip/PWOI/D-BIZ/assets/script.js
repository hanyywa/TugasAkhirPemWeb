// kode script.js yang telah diubah jd jquery

$(document).ready(function () {
  console.log('jQuery ready!');

  // Validasi Formulir
  $('form').on('submit', function (e) {
    e.preventDefault();

    const nama = $('#nama').val().trim();
    const email = $('#email').val().trim();
    const usia = $('#usia').val();
    const pertanyaan = $('#pertanyaan').val().trim();

    if (!nama || !email || !usia) {
      alert('Harap isi semua kolom wajib!');
      return;
    }

    alert(`Terima kasih ${nama}! Pertanyaan Anda telah dikirim.`);
    this.reset();
  });

  // Dark Mode Toggle
  $('#darkModeBtn').on('click', function () {
    $('body').toggleClass('dark-mode');
    $(this).text($('body').hasClass('dark-mode') ? '☀️' : '🌙');
  });

  // Toggle Menu Navigasi
  $('#toggleMenuBtn').on('click', function () {
    $('#menuNavigasi').toggleClass('hidden');
    const isHidden = $('#menuNavigasi').hasClass('hidden');
    $(this).text(isHidden ? 'Show' : 'Hide');
  });

  // Scroll ke Form Konsultasi
  $('#scrollBtn').on('click', function () {
    $('#konsultasi')[0].scrollIntoView({ behavior: 'smooth' });
  });

  // Show Scroll Button
  const observerScroll = new IntersectionObserver(function (entries) {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        $('#scrollBtn').addClass('visible');
      } else {
        $('#scrollBtn').removeClass('visible');
      }
    });
  }, { threshold: 0.5 });
  observerScroll.observe($('header')[0]);

  // Fade-in Sections
  const observerFade = new IntersectionObserver(function (entries) {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        $(entry.target).addClass('visible');
      }
    });
  }, { threshold: 0.2 });

  $('section, .fade-in, #produk li').each(function () {
    observerFade.observe(this);
  });

  // Loader fallback
  const hideLoader = function () {
    console.log('Page fully loaded');
    $('#loader').hide();
  };

  // Backup untuk jaga-jaga jika event load tidak terpanggil
  setTimeout(hideLoader, 4000);

  $(window).on('load', hideLoader);

  // Cart Logic
  let cart = [];

  window.addToCart = function (name, priceStr) {
    const price = parseInt(priceStr.replace(/[^\d]/g, ''));
    cart.push({ name, price });
    updateCartUI();
    alert('Berhasil ditambahkan ke keranjang! 🎉');
  };

  window.updateCartUI = function () {
    const count = cart.length;
    const total = cart.reduce((sum, item) => sum + item.price, 0);

    $('#cart-count').text(count);
    $('#cart-total').text(total.toLocaleString());
    $('#cart-total-detail').text(total.toLocaleString());

    const $cartItems = $('#cart-items');
    $cartItems.empty();

    cart.forEach((item, index) => {
      $cartItems.append(`
        <li>
          ${item.name} - Rp${item.price.toLocaleString()} 
          <button class="remove-btn" onclick="removeFromCart(${index})">×</button>
        </li>
      `);
    });
  };

  window.removeFromCart = function (index) {
    cart.splice(index, 1);
    updateCartUI();
  };

  window.clearCart = function () {
    if (confirm("Apakah kamu yakin ingin mengosongkan keranjang?")) {
      cart = [];
      updateCartUI();
      alert("Keranjang sudah dikosongkan.");
    }
  };

  window.toggleCartDetails = function () {
    $('#cart-detail').toggleClass('hidden');
  };

  window.checkoutNow = function () {
    const total = cart.reduce((sum, item) => sum + item.price, 0);
    const items = cart.map(i => `• ${i.name} - Rp${i.price.toLocaleString()}`).join('%0A');
    const message = `Halo! Saya ingin checkout:%0A${items}%0ATotal: Rp${total.toLocaleString()}`;
    const waURL = `https://wa.me/6285226146689?text=${message}`;
    window.open(waURL, '_blank');
  };
});
